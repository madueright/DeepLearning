load iris.mat
tz=iris(:,2:5);%特征值
rs=iris(:,6);%花种码
temp = randperm(size(tz,1));%乱序处理，随机排列
% 训练集——120个样本
P_train = tz(temp(1:120),:)';
T_train = rs(temp(1:120),:)';
% 测试集——30个样本
P_test = tz(temp(121:150),:)';
T_test = rs(temp(121:150),:)';
N = size(P_test,2);%查询第二个维度(列数)
% 创建网络
net = newff(P_train,T_train,[10 3]);%神经网络铺层
%%%设置神经网络细节%%%
net.trainParam.epochs = 1000;%迭代次数
net.trainParam.goal = 1e-3;%收敛阈值
net.trainParam.lr = 0.01;%学习率（梯度下降的快慢）
%%%%%%%%%%%%%%%%%%%%%
net = train(net,P_train,T_train);%创建网络
T_sim = sim(net,P_test);%模拟函数读取网络和测试集来计算测试结果
error = abs(T_sim - T_test)./T_test;
R2 = (N * sum(T_sim .* T_test) - sum(T_sim) * sum(T_test))^2 / ((N * sum((T_sim).^2) - (sum(T_sim))^2) * (N * sum((T_test).^2) - (sum(T_test))^2));%相合度计算指标
result = [T_test' T_sim' error'];
% figure
plot(1:N,T_test,'b:*',1:N,T_sim,'r-o')
legend('真实值','预测值')
xlabel('预测样本')
ylabel('花种值')
string = {'花种识别';['R^2=' num2str(R2)]};
title(string)